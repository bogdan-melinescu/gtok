import json
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Dict, Any, Union

class ActivityType(str, Enum):
    SOIL_PREPARATION = "soil_preparation"
    PLANTING = "planting"
    MAINTENANCE = "maintenance"
    HARVEST = "harvest"

class ActivityStatus(str, Enum):
    PLANNED = "planned"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

@dataclass
class FarmInfo:
    name: str
    location: str
    version: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FarmInfo':
        return cls(**data)

@dataclass
class Timing:
    planned_month: Optional[str] = None
    planned_date: Optional[str] = None
    estimated_duration_days: Optional[int] = None
    is_estimated: bool = False
    window_start: Optional[str] = None
    window_end: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Timing':
        return cls(**data)

@dataclass
class ResourceItem:
    type: str
    name: Optional[str] = None
    quantity: Optional[float] = None
    unit: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ResourceItem':
        return cls(**data)

@dataclass
class Resources:
    machinery: List[str] = field(default_factory=list)
    inputs: List[ResourceItem] = field(default_factory=list)
    seeds: Optional[ResourceItem] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Resources':
        machinery = data.get('machinery', [])
        inputs_data = data.get('inputs', [])
        inputs = [ResourceItem.from_dict(i) for i in inputs_data]
        
        seeds_data = data.get('seeds')
        seeds = ResourceItem.from_dict(seeds_data) if seeds_data else None
        
        return cls(machinery=machinery, inputs=inputs, seeds=seeds)

@dataclass
class Outputs:
    estimated_yield: Optional[float] = None
    unit: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Outputs':
        return cls(**data)

@dataclass
class Activity:
    id: str
    name: str
    type: str
    status: str
    timing: Timing
    resources: Optional[Resources] = None
    outputs: Optional[Outputs] = None
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Activity':
        timing_data = data.get('timing')
        timing = Timing.from_dict(timing_data) if timing_data else Timing()
        
        resources_data = data.get('resources')
        resources = Resources.from_dict(resources_data) if resources_data else None
        
        outputs_data = data.get('outputs')
        outputs = Outputs.from_dict(outputs_data) if outputs_data else None
        
        return cls(
            id=data['id'],
            name=data['name'],
            type=data['type'],
            status=data['status'],
            timing=timing,
            resources=resources,
            outputs=outputs,
            notes=data.get('notes')
        )

@dataclass
class GDDParams:
    base_temp_c: float
    optimal_temp_c: float
    max_temp_c: float
    method: str = "standard"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'GDDParams':
        return cls(**data)

@dataclass
class WaterParams:
    kc_initial: float
    kc_mid: float
    kc_end: float
    rooting_depth_max_m: float
    depletion_fraction_p: float

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'WaterParams':
        return cls(**data)

@dataclass
class StressThresholds:
    moisture_stress_index_limit: float

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'StressThresholds':
        return cls(**data)

@dataclass
class ScientificParameters:
    gdd_params: GDDParams
    bbch_thresholds: Dict[str, int]
    water_params: WaterParams
    stress_thresholds: Optional[StressThresholds] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ScientificParameters':
        gdd = GDDParams.from_dict(data['gdd_params'])
        water = WaterParams.from_dict(data['water_params'])
        stress = StressThresholds.from_dict(data['stress_thresholds']) if data.get('stress_thresholds') else None
        return cls(
            gdd_params=gdd,
            bbch_thresholds=data.get('bbch_thresholds', {}),
            water_params=water,
            stress_thresholds=stress
        )

@dataclass
class CropSettings:
    irrigation: bool = False
    organic: bool = False
    herbicide: bool = True

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'CropSettings':
        return cls(**data)

@dataclass
class Crop:
    id: str
    name: str
    variety: str
    field_id: str
    year: int
    calendar: List[Activity]
    area_ha: Optional[float] = None
    settings: Optional[CropSettings] = None
    scientific_parameters: Optional[ScientificParameters] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Crop':
        calendar_data = data.get('calendar', [])
        calendar = [Activity.from_dict(a) for a in calendar_data]
        
        settings_data = data.get('settings')
        settings = CropSettings.from_dict(settings_data) if settings_data else None
        
        sci_data = data.get('scientific_parameters')
        sci_params = ScientificParameters.from_dict(sci_data) if sci_data else None
        
        return cls(
            id=data['id'],
            name=data['name'],
            variety=data.get('variety', 'Unknown'),
            field_id=data['field_id'],
            year=data['year'],
            area_ha=data.get('area_ha'),
            settings=settings,
            scientific_parameters=sci_params,
            calendar=calendar
        )

@dataclass
class Coordinate:
    lat: float
    lon: float

    @classmethod
    def from_dict(cls, data: Dict[str, float]) -> 'Coordinate':
        return cls(**data)

@dataclass
class Field:
    id: str
    name: str
    boundary: List[Coordinate]
    area_ha: Optional[float] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Field':
        boundary_data = data.get('boundary', [])
        boundary = [Coordinate.from_dict(pt) for pt in boundary_data]
        return cls(
            id=data['id'],
            name=data['name'],
            boundary=boundary,
            area_ha=data.get('area_ha')
        )

@dataclass
class FarmModel:
    farm_info: FarmInfo
    fields: List[Field]
    crops: List[Crop]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FarmModel':
        info = FarmInfo.from_dict(data['farm_info'])
        
        fields_data = data.get('fields', [])
        fields = [Field.from_dict(f) for f in fields_data]
        
        crops = [Crop.from_dict(c) for c in data['crops']]
        
        return cls(farm_info=info, fields=fields, crops=crops)

    @classmethod
    def load(cls, file_path: str) -> 'FarmModel':
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return cls.from_dict(data)

if __name__ == "__main__":
    # Example usage
    import sys
    
    try:
        model = FarmModel.load("../data/farm_model.json")
        print(f"Successfully loaded farm: {model.farm_info.name}")
        print(f"Location: {model.farm_info.location} ({model.farm_info.latitude}, {model.farm_info.longitude})")
        
        print(f"Found {len(model.fields)} fields:")
        for field in model.fields:
            print(f" - {field.name} (ID: {field.id}, Points: {len(field.boundary)})")

        print(f"Found {len(model.crops)} crops:")
        for crop in model.crops:
            print(f" - {crop.name} (Field: {crop.field_id}, Year: {crop.year})")
            if crop.scientific_parameters:
                print(f"   Base Temp: {crop.scientific_parameters.gdd_params.base_temp_c}C")
            print(f"   Activities: {len(crop.calendar)}")
    except FileNotFoundError:
        print("Error: ../data/farm_model.json not found. Run this script from the src/ directory.")
    except Exception as e:
        print(f"Error loading model: {e}")
