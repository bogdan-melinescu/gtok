import pandas as pd
df = pd.read_csv('data/sensor_timeseries.csv', index_col='last_changed')
target = '2025-08-10 12:27:43.861000+00:00'
print("Target row:")
print(df.loc[target])
print("\nSurrounding rows:")
# find location
idx = df.index.get_loc(target)
print(df.iloc[idx-2:idx+3])
